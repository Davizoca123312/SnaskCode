from lark import Lark
from Snask_Interpreter import SnaskInterpreter

# Carrega a gramática
with open("grammar.lark", "r", encoding="utf-8") as f:
    grammar = f.read()

parser = Lark(grammar, parser="lalr")
interpreter = SnaskInterpreter()

print("🟢 Modo interativo Snask iniciado. Digite 'exit' para sair.")

while True:
    try:
        line = input("snask> ")
        if line.strip().lower() == "exit":
            break
        if not line.strip():
            continue
        tree = parser.parse(line)
        interpreter.transform(tree)
    except Exception as e:
        print(f"❌ Erro: {e}")
