import sys
import os
import requests

BASE_URL = "http://localhost:5000"

def baixar_biblioteca(nome):
    try:
        response = requests.get(f"{BASE_URL}/api/lib/{nome}")
        if response.status_code == 200:
            codigo = response.json()['code']
            os.makedirs("libs", exist_ok=True)
            with open(f"libs/{nome}.snask", "w", encoding="utf-8") as f:
                f.write(codigo)
            print(f"✅ Biblioteca '{nome}' baixada com sucesso em libs/{nome}.snask")
        else:
            print(f"❌ Biblioteca '{nome}' não encontrada no SnaskGet.")
    except Exception as e:
        print(f"Erro: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: snaskget nome_da_biblioteca")
    else:
        nome = sys.argv[1]
        baixar_biblioteca(nome)
