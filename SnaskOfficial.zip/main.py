import sys
import os
from lark import Lark, UnexpectedInput

# Caminho absoluto para o diretório onde este script está
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Importa o interpretador a partir do caminho absoluto
sys.path.insert(0, BASE_DIR)
from Snask_Interpreter import SnaskInterpreter

def carregar_bibliotecas(pasta):
    bibliotecas = {}
    libs_path = os.path.join(BASE_DIR, pasta)
    if os.path.exists(libs_path):
        for arquivo in os.listdir(libs_path):
            if arquivo.endswith(".snask"):
                nome = arquivo[:-6]  # remove ".snask"
                caminho = os.path.join(libs_path, arquivo)
                with open(caminho, "r", encoding="utf-8") as f:
                    codigo = f.read()
                    bibliotecas[nome] = codigo
        print(f"📚 Bibliotecas encontradas: {', '.join(bibliotecas.keys())}")
    else:
        print("📁 Pasta 'libs' não encontrada. Nenhuma biblioteca carregada.")
    return bibliotecas

def executar_codigo(code, parser, interpreter, bibliotecas):
    try:
        tree = parser.parse(code)
        interpreter.bibliotecas = bibliotecas
        interpreter.transform(tree)
    except UnexpectedInput as e:
        print("\n🚨 ERRO DE SINTAXE NO CÓDIGO 🚨")
        print(f"Arquivo: {input_file}")
        print(f"Linha: {e.line}, Coluna: {e.column}")
        print(f"Erro próximo de: {e.get_context(code).strip()}")
        print(f"Detalhes: {e.__class__.__name__}: {str(e).splitlines()[0]}")
        sys.exit(1)
    except Exception as e:
        print("\n🚨 ERRO INTERNO 🚨")
        print(f"Erro: {e.__class__.__name__}: {str(e)}")
        sys.exit(1)

def main():
    global input_file
    if len(sys.argv) < 2:
        print("Uso: snask arquivo.snask")
        sys.exit(1)

    input_file = sys.argv[1]

    grammar_path = os.path.join(BASE_DIR, "grammar.lark")
    with open(grammar_path, "r", encoding="utf-8") as f:
        grammar = f.read()

    parser = Lark(grammar, parser="lalr")
    interpreter = SnaskInterpreter(parser)

    bibliotecas = carregar_bibliotecas("libs")

    with open(input_file, "r", encoding="utf-8") as f:
        code = f.read()

    executar_codigo(code, parser, interpreter, bibliotecas)

if __name__ == "__main__":
    main()
