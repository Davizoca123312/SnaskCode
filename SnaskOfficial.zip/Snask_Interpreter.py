from lark import Transformer, Lark, Token
import time
import os
import requests
import json
from lark.tree import Tree
import importlib

# Habilitar prints de depuração (mude para False para desabilitar)
DEBUG_MODE = True

def debug_print(*args, **kwargs):
    if DEBUG_MODE:
        print("[DEBUG]", *args, **kwargs)

class SnaskInterpreter(Transformer):
    def __init__(self, parser=None):
        self.env = {}
        self.functions = {}
        self.returning = False  # Flag para 'return' de função e 'breaky' de loop
        self.return_value = None
        self.parser = parser # Necessário para use_lib com arquivos .snask
        self.environment = {}
        # Flags específicas para controle de fluxo de loop, para distinguir de 'return'
        self._is_break_signal = False
        self._is_skip_signal = False # Para 'continue' (skipit)

        # Seu código original para reactive_rules
        self.reactive_rules = []
        self.triggered_conditions = set()


    # ==== RESOLUÇÃO E EXECUÇÃO CENTRAL ====

    def _resolve(self, val):
        debug_print(f"_resolve: Recebido: {val!r} (tipo: {type(val)})")
        if isinstance(val, Tree):
            method_name = val.data
            method = getattr(self, method_name, None)
            if method:
                debug_print(f"_resolve: Chamando método '{method_name}' para Tree: {val.data}")
                result = method(val.children)
                debug_print(f"_resolve: Método '{method_name}' retornou: {result!r}")
                return result
            else:
                raise ValueError(f"Nó da árvore com 'data' desconhecido ou não avaliável: {method_name}")

        elif isinstance(val, Token):
            debug_print(f"_resolve: Processando Token: {val.type} '{val.value}'")
            if val.type == "NUMBER":
                # Se a gramática já tem uma regra NUMBER -> number, o método 'number' fará a conversão.
                # Se _resolve recebe o Token NUMBER diretamente:
                v_str = str(val.value)
                return float(v_str) if '.' in v_str or 'e' in v_str.lower() else int(v_str)
            elif val.type == "ESCAPED_STRING": # common.ESCAPED_STRING já processa
                return val.value
            elif val.type == "STRING": # Para um token STRING genérico que precisa de processamento
                return str(val.value[1:-1].encode('utf-8').decode('unicode_escape'))
            elif val.type == "NAME":
                varname = val.value
                if varname in self.env:
                    return self.env[varname]["value"]
                # Adicionar checagem para 'true'/'false' se forem NAMEs e não keywords dedicadas
                elif varname == "true": return True
                elif varname == "false": return False
                elif varname in self.functions:
                    raise NameError(f"Tentativa de usar função '{varname}' como variável. Para chamar, use 'call {varname}(...)'.")
                raise NameError(f"Variável ou nome '{varname}' não encontrado.")
            # Adicione aqui outros tipos de Tokens se necessário (ex: BOOL_TRUE, BOOL_FALSE)
            else:
                debug_print(f"_resolve: Token não tratado especificamente, retornando valor: {val.value!r}")
                return val.value # Ou erro se o token não for esperado como valor direto

        # Se for um valor Python já resolvido (int, str, bool, list, dict, etc.), retorna diretamente
        debug_print(f"_resolve: Valor já é Python, retornando: {val!r}")
        return val
    

    def add(self, items):
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left + right

    def sub(self, items):
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left - right

    def mul(self, items):
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left * right

    def div(self, items):
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left / right

    def eq(self, items):
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left == right

    def aint(self, items):  # equivalente ao !=
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left != right

    def over(self, items):  # equivalente a >
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left > right

    def under(self, items):  # equivalente a <
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left < right

    def overeq(self, items):  # >=
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left >= right

    def undereq(self, items):  # <=
     left = self._resolve(items[0])
     right = self._resolve(items[1])
     return left <= right

    def _execute(self, stmt_node):
        # Se um 'return' de função foi acionado, não executa mais nada no escopo atual da função.
        # 'breaky' e 'skipit' são tratados pelos loops.
        if self.returning and not (self._is_break_signal or self._is_skip_signal):
            debug_print(f"_execute: Retornando cedo devido a 'self.returning' ser True (e não break/skip)")
            return

        if self._is_skip_signal: # Se um skipit foi acionado, esta instrução não roda.
            debug_print(f"_execute: Sinal de skip detectado, não executando {stmt_node!r}")
            # A flag _is_skip_signal deve ser resetada pelo loop que a detecta.
            return

        debug_print(f"_execute: Executando nó: {stmt_node!r}")

        if hasattr(stmt_node, "data"): # Verifica se é uma Tree válida com um tipo de instrução
            method_name = stmt_node.data
            method = getattr(self, method_name, None)
            
            if method:
                debug_print(f"_execute: Chamando método do Transformer '{method_name}' para: {stmt_node.data}")
                method(stmt_node.children)
            else:
                # Se não houver um método, pode ser uma expressão usada como instrução (valor descartado)
                # Ex: uma chamada de função `minhaFunc();`
                debug_print(f"_execute: Sem método Transformer para '{method_name}', tentando resolver como expressão.")
                try:
                    self._resolve(stmt_node) # Resolve e descarta o resultado
                except ValueError as e:
                    print(f"AVISO: Instrução ou expressão desconhecida '{method_name}': {e}")
                except Exception as e_res:
                    print(f"ERRO ao tentar resolver instrução '{method_name}' como expressão: {e_res}")
        elif isinstance(stmt_node, Token):
            print(f"AVISO: Token '{stmt_node}' encontrado onde uma instrução era esperada. Ignorando.")
        else:
            print(f"AVISO: Objeto inesperado '{stmt_node}' (tipo {type(stmt_node)}) encontrado onde uma instrução era esperada. Ignorando.")

        # Checar regras reativas (se implementado e relevante)
        # if not self.returning and not self._is_break_signal and not self._is_skip_signal:
        #    self._check_reactive_rules()

    def _execute_tree(self, tree):
        """ Executa todas as instruções em uma árvore de programa. """
        if not hasattr(tree, 'children'):
            return
        for stmt_node in tree.children:
            self._execute(stmt_node)
            # Se um return de função ocorrer no nível superior, encerra a execução da árvore.
            # Break/skip no nível superior também encerram.
            if self.returning or self._is_break_signal or self._is_skip_signal:
                debug_print(f"_execute_tree: Parando execução da árvore devido a returning/break/skip.")
                if self._is_break_signal: # Consome o break no nível da árvore
                    self._is_break_signal = False
                    self.returning = False # Break não deve propagar como return de função
                if self._is_skip_signal: # Consome o skip
                     self._is_skip_signal = False
                break


    # ==== VARIÁVEIS E CONSTANTES ====
    def var_decl(self, items):
        # items: [Token(NAME, name), type_node, expr_node] (assumindo que type_node é o resultado de self.type)
        name_token = items[0] # Token NAME
        type_str_from_rule = self.type(items[1].children if hasattr(items[1], 'data') else items[1]) # items[1] é nó 'type'
        value_node = items[2]

        name = str(name_token.value)
        value = self._resolve(value_node)

        debug_print(f"var_decl: nome='{name}', tipo_declarado='{type_str_from_rule}', valor_resolvido={value!r}")

        if name.isdigit():
         raise ValueError(f"Nome inválido para variável: '{name}' não pode ser um número.")
        
        if not self._check_type(value, type_str_from_rule):
            actual_type = self.typeis([value]) # typeis espera uma lista
            raise TypeError(f"Tipo inválido para '{name}'. Esperado '{type_str_from_rule}', recebeu '{actual_type}' (valor: {value!r}).")

        self.env[name] = {"type": type_str_from_rule, "value": value, "constant": False}
        debug_print(f"var_decl: Variável '{name}' definida no ambiente: {self.env[name]}")

    def const_decl(self, items):
        self.var_decl(items) # Declara como var normal
        name = str(items[0].value)
        if name in self.env:
            self.env[name]["constant"] = True # Marca como constante
            debug_print(f"const_decl: Variável '{name}' marcada como constante.")


    def type(self, items):
     type_val = items[0]
     if isinstance(type_val, Token):
        type_str = str(type_val.value)
     else:
        type_str = str(type_val)

     aliases = {
        "i": "int",
        "s": "str",
        "f": "float",
        "b": "bool",
        "v": "void",
        "l": "list",
        "d": "dict",
        "m": "module",
        "a": "any"
    }

     return aliases.get(type_str, type_str)



    def var_set(self, items):
        # items: [Token(NAME, name), expr_node]
        name_token = items[0] # Token NAME
        value_node = items[1]
        
        name = str(name_token.value)
        value = self._resolve(value_node)
        debug_print(f"var_set: Tentando setar '{name}' para {value!r}")

        if name not in self.env:
            raise NameError(f"Variável '{name}' não foi declarada antes de ser definida.")

        if self.env[name].get("constant", False):
            raise TypeError(f"Não é possível alterar o valor da constante '{name}'.")

        expected_type = self.env[name]["type"]
        if not self._check_type(value, expected_type):
            actual_type = self.typeis([value])
            raise TypeError(f"Tipo inválido ao alterar '{name}'. Esperado '{expected_type}', recebeu '{actual_type}' (valor: {value!r}).")

        self.env[name]["value"] = value
        debug_print(f"var_set: Variável '{name}' atualizada para: {self.env[name]}")


    def _check_type(self, value, expected_str_type):
     debug_print(f"_check_type: valor={value!r} (tipo {type(value).__name__}), esperado='{expected_str_type}'")
     if expected_str_type == "any": return True
     
     py_type_name = type(value).__name__

     if expected_str_type == "int": return isinstance(value, int)
     if expected_str_type == "float": return isinstance(value, (int, float)) # float pode aceitar int
     if expected_str_type == "str": return isinstance(value, str)
     if expected_str_type == "list": return isinstance(value, list)
     if expected_str_type == "dict": return isinstance(value, dict)
     if expected_str_type == "bool": return isinstance(value, bool)
     if expected_str_type == "void": return value is None
     if expected_str_type == "module": return hasattr(value, '__name__') and hasattr(value, '__file__') # Checagem simples para módulo

     # Se chegou aqui, tipo desconhecido ou incompatível
     debug_print(f"_check_type: Falhou. Valor tipo '{py_type_name}' não é '{expected_str_type}'")
     return False

    def var_zap(self, items): # items: [Token(NAME, name)]
        name = str(items[0].value)
        if name in self.env:
            del self.env[name]
            debug_print(f"var_zap: Variável '{name}' deletada.")
        else:
            print(f"AVISO: Variável '{name}' não encontrada para deletar (zap).")


    # ==== BUILT-IN FUNCS como MÉTODOS (lenof, typeis, etc.) ====
    # Estes são chamados quando a gramática os transforma em nós com 'data' correspondente.
    # Ex: lenof_expr: "lenof" "(" expr ")" -> lenof
    
    def lenof(self, items): # items: [expr_node]
         val = self._resolve(items[0])
         try:
            return len(val)
         except TypeError:
            raise TypeError(f"Objeto do tipo '{self.typeis([val])}' não tem tamanho (len).")

    def typeis(self, items): # items: [expr_node] ou [valor_python] se chamado internamente
        # Precisa lidar com ambos os casos. _resolve(items[0]) se for expr_node.
        if items and isinstance(items[0], (Tree, Token)):
            val = self._resolve(items[0])
        elif items: # Já é um valor Python
            val = items[0]
        else: # Chamada inválida
            raise ValueError("typeis chamado sem argumento.")

        py_type = type(val).__name__
        snask_types = {
            "str": "str", "int": "int", "float": "float",
            "list": "list", "dict": "dict", "bool": "bool",
            "NoneType": "void", "module": "module"
        }
        return snask_types.get(py_type, py_type) # Retorna nome Python se não mapeado


    def toupper(self, items): # items: [expr_node_str]
        val = self._resolve(items[0])
        if not isinstance(val, str): raise TypeError("toupper espera uma string.")
        return val.upper()

    def tolower(self, items): # items: [expr_node_str]
        val = self._resolve(items[0])
        if not isinstance(val, str): raise TypeError("tolower espera uma string.")
        return val.lower()

    def startswith(self, items): # items: [expr_node_str, expr_node_prefix]
        val = self._resolve(items[0])
        prefix = self._resolve(items[1])
        if not isinstance(val, str) or not isinstance(prefix, str):
            raise TypeError("startswith espera dois argumentos string.")
        return val.startswith(prefix)

    def endswith(self, items): # items: [expr_node_str, expr_node_suffix]
        val = self._resolve(items[0])
        suffix = self._resolve(items[1])
        if not isinstance(val, str) or not isinstance(suffix, str):
            raise TypeError("endswith espera dois argumentos string.")
        return val.endswith(suffix)

    # ==== LITERAIS e ACESSO A COLEÇÕES ====
    def list_literal(self, items):
     resolved = []
     for item in items:
        val = self._resolve(item)
        if isinstance(val, str):
            # Verifica se a string ainda tem aspas embutidas
            if val.startswith('"') and val.endswith('"'):
                inner = val[1:-1]
                if '"' in inner or "'" in inner:
                    raise ValueError(f"String inválida com aspas extras: {val!r}")
                val = inner
            elif val.count('"') > 0:
                raise ValueError(f"String malformada: {val!r} — use aspas apenas ao redor da palavra")
        resolved.append(val)
     return resolved
    

    def pack_get(self, items):
     name_token = items[0]
     index_node = items[1]

     name = str(name_token.value)
     index = self._resolve(index_node)

     if name not in self.env:
        raise NameError(f"Lista '{name}' não foi declarada.")
     lista = self.env[name]["value"]

     if not isinstance(lista, list):
        raise TypeError(f"'{name}' não é uma lista.")
     if not isinstance(index, int):
        raise TypeError(f"O índice fornecido deve ser inteiro.")

     if index < 0 or index >= len(lista):
        raise IndexError(f"Índice {index} fora do limite da lista '{name}'.")

     return lista[index]


    def dict_literal(self, items): # items: [key_node1, val_node1, key_node2, val_node2, ...]
        d = {}
        for i in range(0, len(items), 2):
            # Chave pode ser um Token NAME, Token ESCAPED_STRING, ou o resultado de uma expressão.
            # Se for Token NAME, seu valor é a string da chave.
            # Se for Token ESCAPED_STRING, seu valor já é a string.
            # Se for uma expressão, resolve.
            key_item = items[i]
            if isinstance(key_item, Token) and key_item.type == "NAME":
                key = str(key_item.value)
            elif isinstance(key_item, Token) and key_item.type == "ESCAPED_STRING":
                key = key_item.value # Já é string
            else: # Pode ser um nó de expressão para a chave
                key = str(self._resolve(key_item)) # Converte para string por via das dúvidas
            
            value = self._resolve(items[i+1])
            d[key] = value
        return d

    def index_access(self, items): # items: [collection_node, index_expr_node]
        collection = self._resolve(items[0])
        index_val = self._resolve(items[1])
        try:
            return collection[index_val]
        except (KeyError, IndexError) as e:
            raise type(e)(f"Erro ao acessar índice/chave '{index_val}' em '{collection!r}': {e}")
        except TypeError:
            actual_collection_type = self.typeis([collection])
            raise TypeError(f"Objeto do tipo '{actual_collection_type}' não suporta indexação (valor: {collection!r}).")


    # ==== FUNÇÕES EXTERNAS (JSON, HTTP) ====
    def jsonparse(self, items): # items: [expr_node_json_string]
        raw = self._resolve(items[0])
        if not isinstance(raw, str): raise TypeError("jsonparse espera uma string.")
        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            raise ValueError(f"Erro ao decodificar JSON: {e}")

    def httpget(self, items): # items: [expr_node_url_string]
        url = self._resolve(items[0])
        if not isinstance(url, str): raise TypeError("httpget espera uma URL (string).")
        try:
            response = requests.get(url, timeout=10) # Adicionado timeout
            response.raise_for_status() # Levanta erro para 4xx/5xx
            return response.text
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Erro na requisição HTTP para '{url}': {e}")


    # ==== INPUT E OUTPUT ====
    def print_stmt(self, items):
        # items: [expr_to_print_node, optional_cdr_chain_result]
        # Se cdr_chain for uma regra que produz uma lista de valores resolvidos:
        # print_stmt: "shoo" "(" expr ("," cdr_chain)? ")"
        # cdr_chain: expr ("," expr)* -> retorna lista de valores resolvidos

        val_to_print_node = items[0]
        val_to_print = self._resolve(val_to_print_node)

        extra_args = []
        if len(items) > 1 and items[1] is not None:
            # items[1] é o resultado de cdr_chain, que deve ser uma lista de valores já resolvidos
            if isinstance(items[1], list):
                extra_args = items[1]
            else: # Caso inesperado se cdr_chain estiver bem definido
                debug_print(f"print_stmt: cdr_chain inesperado, tipo {type(items[1])}, valor {items[1]!r}")
                extra_args = [self._resolve(items[1])] # Tenta resolver como um único item

        if isinstance(val_to_print, str) and '{}' in val_to_print and extra_args:
            try:
                # Garante que todos os args para formatação sejam strings
                str_extra_args = [str(arg) for arg in extra_args]
                # Limita o número de argumentos passados para format ao número de placeholders
                num_placeholders = val_to_print.count("{}")
                print(val_to_print.format(*str_extra_args[:num_placeholders]))
            except IndexError: # Menos placeholders que argumentos, ou vice-versa (se format for estrito)
                print(val_to_print, *extra_args) # Imprime separadamente
            except Exception as e_fmt: # Outro erro de formatação
                debug_print(f"print_stmt: Erro de formatação '{e_fmt}', imprimindo separadamente.")
                print(val_to_print, *extra_args)
        elif extra_args:
            print(val_to_print, *extra_args)
        else:
            print(val_to_print)
        
    

    def input_stmt(self, items):
     name_token, type_node = items
     var_name = str(name_token.value)

     if isinstance(type_node, Tree):
        expected_type = self.type(type_node.children)
     else:
        expected_type = str(type_node)

     entrada = input()
     valor = self._converter_input(entrada, expected_type)

     self.environment[var_name] = {
        "type": expected_type,
        "value": valor,
        "constant": False
     }

     debug_print(f"input_stmt: '{var_name}' <- {valor} ({expected_type})")


    def inputnum_stmt(self, items):
     name_token, type_node = items
     var_name = str(name_token.value)

     if isinstance(type_node, Tree):
        expected_type = self.type(type_node.children)
     else:
        expected_type = str(type_node)

     entrada = input()

     try:
        valor = int(entrada)
     except ValueError:
        raise TypeError(f"Valor inválido para tipo '{expected_type}': {entrada}")

     self.environment[var_name] = {
        "type": expected_type,
        "value": valor,
        "constant": False
     }

     debug_print(f"inputnum_stmt: '{var_name}' <- {valor} ({expected_type})")


    def inputtxt_stmt(self, items):
     name_token, type_node = items
     var_name = str(name_token.value)

     if isinstance(type_node, Tree):
        expected_type = self.type(type_node.children)
     else:
        expected_type = str(type_node)

     valor = input()

     if expected_type != "str":
        raise TypeError(f"grabtxt só aceita tipo 'str', mas recebeu '{expected_type}'")

     self.environment[var_name] = {
        "type": expected_type,
        "value": valor,
        "constant": False
    }

     debug_print(f"inputtxt_stmt: '{var_name}' <- {valor} ({expected_type})")


    def cdr_chain(self, items): # items: [expr_node1, expr_node2, ...]
        # Este método é chamado pela regra `cdr_chain: expr ("," expr)*`
        # Ele recebe os *resultados* das expressões já resolvidas (se `expr` for um terminal ou alias para um método)
        # ou os nós `expr` em si.
        # Para ser consistente e retornar uma lista de valores resolvidos:
        return [self._resolve(item) for item in items]

    
    def sub(self, items):
        left = self._resolve(items[0])
        right = self._resolve(items[1])
        if isinstance(left, (int, float)) and isinstance(right, (int, float)): return left - right
        raise TypeError(f"Operação '-' não suportada entre tipos '{self.typeis([left])}' e '{self.typeis([right])}'.")

    def mul(self, items):
        left = self._resolve(items[0])
        right = self._resolve(items[1])
        if isinstance(left, (int, float)) and isinstance(right, (int, float)): return left * right
        if (isinstance(left, str) and isinstance(right, int)) or \
           (isinstance(left, int) and isinstance(right, str)): return left * right
        if (isinstance(left, list) and isinstance(right, int)) or \
           (isinstance(left, int) and isinstance(right, list)): return left * right # Python lida com a ordem
        raise TypeError(f"Operação '*' não suportada entre tipos '{self.typeis([left])}' e '{self.typeis([right])}'.")

    def div(self, items):
        left = self._resolve(items[0])
        right = self._resolve(items[1])
        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            if right == 0: raise ZeroDivisionError("Divisão por zero.")
            return left / right # Divisão de ponto flutuante
        raise TypeError(f"Operação '/' não suportada entre tipos '{self.typeis([left])}' e '{self.typeis([right])}'.")

    # Operadores de Comparação
    def is_(self, items): # 'is' para igualdade (==)
        return self._resolve(items[0]) == self._resolve(items[1])

    def aint(self, items): # 'aint' para desigualdade (!=)
        return self._resolve(items[0]) != self._resolve(items[1])

    def over(self, items): # '>'
        left = self._resolve(items[0]); right = self._resolve(items[1])
        if isinstance(left, (int, float, str)) and type(left) == type(right): return left > right
        if isinstance(left, (int, float)) and isinstance(right, (int, float)): return left > right
        raise TypeError(f"Operador '>' (over) não suportado entre '{self.typeis([left])}' e '{self.typeis([right])}'.")

    def lt(self, items): # '<'
        left = self._resolve(items[0]); right = self._resolve(items[1])
        if isinstance(left, (int, float, str)) and type(left) == type(right): return left < right
        if isinstance(left, (int, float)) and isinstance(right, (int, float)): return left < right
        raise TypeError(f"Operador '<' (lt) não suportado entre '{self.typeis([left])}' e '{self.typeis([right])}'.")

    def gte(self, items): # '>='
        left = self._resolve(items[0]); right = self._resolve(items[1])
        if isinstance(left, (int, float, str)) and type(left) == type(right): return left >= right
        if isinstance(left, (int, float)) and isinstance(right, (int, float)): return left >= right
        raise TypeError(f"Operador '>=' (gte) não suportado entre '{self.typeis([left])}' e '{self.typeis([right])}'.")

    def lte(self, items): # '<=' (undereq é um alias para este)
        left = self._resolve(items[0]); right = self._resolve(items[1])
        if isinstance(left, (int, float, str)) and type(left) == type(right): return left <= right
        if isinstance(left, (int, float)) and isinstance(right, (int, float)): return left <= right
        raise TypeError(f"Operador '<=' (lte/undereq) não suportado entre '{self.typeis([left])}' e '{self.typeis([right])}'.")

    def undereq(self, items): # Alias para lte
        return self.lte(items)
        
    # Se a gramática usa 'gt', '<', etc. como nomes de regra, estes são redundantes se over/lt já existem
    # def gt(self, items): return self.over(items)


    # Para regras como NUMBER -> number
    def number(self, token_list): # token_list é [Token(NUMBER, "123")]
        token = token_list[0]
        val_str = str(token.value)
        return float(val_str) if '.' in val_str or 'e' in val_str.lower() else int(val_str)

    # Para regra ESCAPED_STRING -> string
    # (common.ESCAPED_STRING já lida com escapes e remoção de aspas)
    def string(self, token_list):
     raw = token_list[0].value  # Ex: '"maçã"'
     return raw[1:-1].encode("utf-8").decode("unicode_escape")


    # Para regra NAME -> var (lookup de variável em expressão)
    def var(self, token_list): # token_list é [Token(NAME, "varname")]
        varname = str(token_list[0].value)
        if varname not in self.env:
            # Checar se é true/false sendo usado como var
            if varname == "true": return True
            if varname == "false": return False
            raise NameError(f"Variável '{varname}' não encontrada em expressão.")
        return self.env[varname]["value"]

    # Para regra "(" expr ")" -> paren_expr
    def paren_expr(self, items): # items é [resultado_da_expr_interna]
        # Se expr interna já foi resolvida pelo seu próprio método transformer:
        return items[0]
        # Se expr interna é um nó que precisa ser resolvido:
        # return self._resolve(items[0])


    # ==== FUNÇÕES DA LINGUAGEM ====
    def func_decl(self, items):
        # func NAME ( param_list? ) -> type { statement* }
        # items: [Token(NAME, func_name), param_list_node?, return_type_node, body_block_node]
        # (a ordem exata e se param_list é None ou um nó vazio depende da gramática)

        name_token = items[0]
        # A gramática de exemplo tem param_list opcional. Se ausente, Lark pode passar None
        # ou um nó 'param_list' vazio.
        # Assumindo que items[1] é param_list_node OU None
        # items[2] é o nó 'type' do retorno
        # items[3] é o nó 'block' (ou similar) para o corpo
        
        idx = 1
        param_list_node = None
        # Heurística para encontrar param_list_node (se houver)
        if len(items) > idx and items[idx] is not None and ( (hasattr(items[idx], 'data') and items[idx].data == 'param_list') or isinstance(items[idx], list) ):
            param_list_node = items[idx]
            idx += 1
        
        return_type_node = items[idx]; idx +=1
        body_node = items[idx] # Geralmente um nó 'block' cujos children são as statements

        name = str(name_token.value)
        params_dict = {}

        if param_list_node: # Se não for None e tiver children
            # param_list_node.children são os nós param_decl
            for param_decl_node in param_list_node.children:
                # param_decl_node.children: [Token(NAME, param_name), type_node]
                param_name = str(param_decl_node.children[0].value)
                param_type_str = self.type(param_decl_node.children[1].children) # type_node -> type -> Token
                params_dict[param_name] = param_type_str
        
        return_type_str = self.type(return_type_node.children)

        self.functions[name] = {"params": params_dict, "return_type": return_type_str, "body_node": body_node}
        debug_print(f"func_decl: Função '{name}' declarada. Params: {params_dict}, Retorno: {return_type_str}")


    def craft(self, items):
     debug_print(f"craft: Iniciando definição de função com items: {items}")

     func_name_token = items[0]
     func_name = str(func_name_token.value)

     # Achar o índice onde está o tipo de retorno
     return_type_idx = None
     for i in range(len(items)):
        if isinstance(items[i], Tree) and items[i].data == "type":
            return_type_idx = i
            break
        elif isinstance(items[i], str) and items[i] in ["int", "str", "float", "bool", "list", "dict", "void", "any"]:
            return_type_idx = i
            break

     if return_type_idx is None:
        raise SyntaxError("craft: Tipo de retorno não encontrado.")

     # Itens entre nome e tipo de retorno são os parâmetros
     param_items = items[1:return_type_idx]
     return_type_raw = items[return_type_idx]

     # Itens depois do tipo de retorno até antes do 'done' são o corpo da função
     body_items = [stmt for stmt in items[return_type_idx + 1:] if stmt is not None]

    # Processar parâmetros
     params_dict = {}
     for param in param_items:
        if isinstance(param, Tree) and param.data == "param":
            pname_token, ptype_node = param.children
            pname = str(pname_token.value)
            ptype = self.type(ptype_node.children if hasattr(ptype_node, 'children') else [ptype_node])
            params_dict[pname] = ptype

    # Processar tipo de retorno
     if isinstance(return_type_raw, Tree):
        return_type_str = self.type(return_type_raw.children)
     else:
        return_type_str = str(return_type_raw)

    # Armazenar a função no dicionário, sem executar ainda
     self.functions[func_name] = {
        "params": params_dict,
        "return_type": return_type_str,
        "body_node": Tree("body", body_items)
    }

     debug_print(f"craft: Função '{func_name}' declarada com parâmetros {params_dict} e retorno '{return_type_str}'")

    

    def func_call(self, items): # Chamada de função como EXPRESSÃO
        # items: [Token(NAME, func_name), arg_list_node?]
        func_name_token = items[0]
        arg_list_node = items[1] if len(items) > 1 else None # Pode ser None se sem args

        func_name = str(func_name_token.value)
        debug_print(f"func_call: Chamando função '{func_name}' como expressão.")

        if func_name not in self.functions:
            raise NameError(f"Função '{func_name}' não definida.")

        func_def = self.functions[func_name]
        resolved_args = []

        if arg_list_node: # Se não for None e tiver children (nós de expressão dos argumentos)
             resolved_args = [self._resolve(arg_expr_node) for arg_expr_node in arg_list_node.children]
        
        return self._execute_function_body(func_name, func_def, resolved_args)

    def func_call_stmt(self, items): # Chamada de função como INSTRUÇÃO (call myFunc(...))
        # items: [func_call_expr_node] (o nó da regra `func_call` que é uma expressão)
        # A gramática `call_stmt: "call" func_call_expr -> func_call_stmt`
        # O `func_call_expr` (items[0]) já terá sido transformado em seu valor de retorno pelo método `func_call`.
        # Aqui, apenas nos certificamos de que ele seja avaliado.
        debug_print(f"func_call_stmt: Executando chamada de função como instrução.")
        self._resolve(items[0]) # Resolve a expressão func_call, descartando o resultado.

    def _execute_function_body(self, func_name, func_def, resolved_args):
        expected_params_def = func_def["params"] # Dicionário {name: type_str}

        if len(resolved_args) != len(expected_params_def):
            raise TypeError(
                f"Função '{func_name}' espera {len(expected_params_def)} argumentos ({list(expected_params_def.keys())}), "
                f"mas recebeu {len(resolved_args)}."
            )

        # Salvar ambiente e estado de retorno do chamador
        # A função opera em uma cópia do ambiente para ter seu próprio escopo para parâmetros
        # e variáveis locais, mas ainda pode "ver" o escopo do chamador (closures).
        original_env = self.env
        self.env = self.env.copy() 
        
        original_returning = self.returning
        original_return_value = self.return_value
        # Resetar para a execução desta função
        self.returning = False
        self.return_value = None
        self._is_break_signal = False # Break/skip não devem vazar de uma função para outra
        self._is_skip_signal = False


        # Configurar parâmetros no novo ambiente da função
        for (param_name, param_type_str), arg_val in zip(expected_params_def.items(), resolved_args):
            if not self._check_type(arg_val, param_type_str):
                actual_arg_type = self.typeis([arg_val])
                raise TypeError(
                    f"Argumento '{param_name}' para função '{func_name}': esperado '{param_type_str}', "
                    f"recebeu '{actual_arg_type}' (valor: {arg_val!r})."
                )
            self.env[param_name] = {"type": param_type_str, "value": arg_val, "constant": False}

        debug_print(f"_execute_function_body: Ambiente da função '{func_name}' antes da execução: {self.env}")

        # Executar o corpo da função (o nó 'block' cujos children são as statements)
        body_node = func_def["body_node"]
        if body_node and hasattr(body_node, 'children'):
            for stmt_node in body_node.children:
                self._execute(stmt_node)
                if self.returning: # Se um 'return' (ou break/skip dentro da func) ocorreu
                    break 
        
        # Capturar o valor de retorno desta função
        result_for_this_call = self.return_value

        # Restaurar ambiente e estado de retorno do chamador
        self.env = original_env
        self.returning = original_returning # Importante: não propagar o 'returning' da função se ela completou
        self.return_value = original_return_value
        # Flags de break/skip também são restauradas (não devem vazar)
        # (Se uma função pudesse causar break em um loop externo, seria mais complexo)

        # Validar o tipo do valor retornado
        expected_return_type = func_def["return_type"]
        if not self._check_type(result_for_this_call, expected_return_type):
            actual_returned_type = self.typeis([result_for_this_call])
            raise TypeError(
                f"Função '{func_name}' deveria retornar '{expected_return_type}', "
                f"mas retornou '{actual_returned_type}' (valor: {result_for_this_call!r})."
            )
        
        debug_print(f"_execute_function_body: Função '{func_name}' retornando: {result_for_this_call!r}")
        return result_for_this_call

    def return_stmt(self, items): # items: [optional_expr_node]
        if items and items[0] is not None:
            self.return_value = self._resolve(items[0])
        else: # return; (para void)
            self.return_value = None
        self.returning = True # Sinaliza que um retorno está em progresso
        debug_print(f"return_stmt: 'returning' setado para True, valor: {self.return_value!r}")


    # ==== CONTROLE DE FLUXO (WHEN, LOOPS) ====
    def when(self, items):
        # items: [condition_node, stmt_node1, stmt_node2, ...]
        # (se a gramática for `when expr { stmt* }`, Lark passa os stmt* como items[1:])
        condition_node = items[0]
        body_statements = items[1:] # Nós das instruções dentro do bloco when

        debug_print(f"when: Avaliando condição: {condition_node!r}")
        condition_result = self._resolve(condition_node)
        debug_print(f"when: Resultado da condição: {condition_result!r} (tipo: {type(condition_result)})")

        if condition_result: # Pythonic truthiness (0, None, "", [] são False)
            debug_print(f"when: Condição VERDADEIRA. Executando corpo...")
            # 'when' (como 'if') não cria novo escopo por padrão.
            # Salvar estado de returning/break/skip ANTES de entrar no bloco
            # para que um break/skip dentro do when não afete o when em si, mas sim o loop externo.
            # Mas 'return' deve propagar.
            
            # Para executar o corpo:
            for stmt_node in body_statements:
                self._execute(stmt_node)
                # Se um 'return' de função ocorrer dentro do 'when', ele deve parar a execução
                # do corpo do 'when' e propagar o 'returning'.
                # Se um 'breaky' ou 'skipit' ocorrer, ele também deve parar o corpo do 'when'
                # e as flags (_is_break_signal, _is_skip_signal) serão vistas pelo loop externo.
                if self.returning or self._is_break_signal or self._is_skip_signal:
                    debug_print(f"when: Saindo do corpo do 'when' devido a returning/break/skip.")
                    break 
        else:
            debug_print(f"when: Condição FALSA. Corpo não será executado.")
        
            
    def loop_spin(self, items): # spin condition { statements }
        condition_node = items[0]
        body_statements = items[1:]
        debug_print(f"loop_spin: Iniciando loop com condição {condition_node!r}")

        while self._resolve(condition_node): # Avalia a condição a cada iteração
            debug_print(f"loop_spin: Condição do loop VERDADEIRA.")
            for stmt_node in body_statements:
                self._execute(stmt_node)
                
                if self._is_skip_signal:
                    debug_print(f"loop_spin: 'skipit' detectado. Indo para próxima iteração.")
                    self._is_skip_signal = False # Consome o sinal de skip
                    break # Sai do for de statements, continua o while

                if self._is_break_signal:
                    debug_print(f"loop_spin: 'breaky' detectado. Saindo do loop.")
                    self._is_break_signal = False # Consome o sinal de break
                    self.returning = False # 'breaky' não é um 'return' de função
                    return # Sai do método loop_spin

                if self.returning: # Se um 'return' de função ocorreu
                    debug_print(f"loop_spin: 'return' de função detectado. Saindo do loop e propagando.")
                    return # Propaga o return, saindo do loop_spin
            
            # Se o loop de statements terminou sem break/skip/return, continua o while
            if self._is_skip_signal: # Se o break interno do 'for' foi por skip, reseta e continua
                self._is_skip_signal = False
                continue

        debug_print(f"loop_spin: Condição do loop FALSA ou loop interrompido. Fim do loop_spin.")


    def loop_loopy(self, items): # loopy { statements }
        body_statements = items # Não há condition_node
        debug_print(f"loop_loopy: Iniciando loop infinito.")
        while True:
            for stmt_node in body_statements:
                self._execute(stmt_node)

                if self._is_skip_signal:
                    debug_print(f"loop_loopy: 'skipit' detectado. Indo para próxima iteração.")
                    self._is_skip_signal = False # Consome o skip
                    break # Sai do for, continua o while

                if self._is_break_signal:
                    debug_print(f"loop_loopy: 'breaky' detectado. Saindo do loop.")
                    self._is_break_signal = False # Consome o break
                    self.returning = False
                    return # Sai do loopy

                if self.returning: # Return de função
                    debug_print(f"loop_loopy: 'return' de função detectado. Saindo do loop e propagando.")
                    return # Propaga o return
            
            if self._is_skip_signal: # Se o break interno do 'for' foi por skip
                self._is_skip_signal = False
                continue
        # Este loop só sai por breaky ou return.

    def loop_breaky(self, _):
        debug_print(f"loop_breaky: Sinal de BREAK ativado.")
        self._is_break_signal = True
        # self.returning = True # 'breaky' pode usar 'returning' se for mais simples,
                              # mas _is_break_signal é mais claro para distinguir de 'return func'.
                              # Se usar self.returning, os loops precisam resetá-lo após consumir o break.

    def loop_skipit(self, _):
        debug_print(f"loop_skipit: Sinal de SKIP ativado.")
        self._is_skip_signal = True


    # ==== LISTAS (PACK) E DICIONÁRIOS (BOX) - Simplificado ====
    # Se quiser tipos específicos como "lista de int", precisaria de mais lógica.
    # Aqui, "list" e "dict" são genéricos.
    def pack_decl(self, items):  # items: [Token(NAME), type_node, list_literal_node]
     name_token = items[0]
     type_node = items[1]
     list_expr_node = items[2]

     name = str(name_token.value)
     expected_type = self.type(type_node.children if hasattr(type_node, 'data') else type_node)
     value = self._resolve(list_expr_node)

     if expected_type != "list":
        raise TypeError(f"pack_decl só aceita tipo 'list', mas você escreveu '{expected_type}'.")

     if not isinstance(value, list):
        raise TypeError(f"Valor atribuído a '{name}' não é uma lista (tipo: {self.typeis([value])}).")

     self.env[name] = {"type": "list", "value": value, "constant": False}


    def pack_add(self, items): # pack_add mylist, element -> items: [Token(NAME, mylist), element_expr_node]
        name_token = items[0]
        element_node = items[1]
        name = str(name_token.value)
        
        if name not in self.env or self.env[name]["type"] != "list":
            raise NameError(f"'{name}' não é uma lista declarada para pack_add.")
        
        element_value = self._resolve(element_node)
        self.env[name]["value"].append(element_value)

    # pack_get é melhor tratado por index_access: mylist[idx]

    def box_decl(self, items): # box mydict = {"k": "v"} -> items: [Token(NAME, mydict), dict_literal_node]
        name_token = items[0]
        dict_expr_node = items[1]
        name = str(name_token.value)
        value = self._resolve(dict_expr_node)
        if not isinstance(value, dict):
            raise TypeError(f"box_decl para '{name}' espera um dicionário, recebeu {self.typeis([value])}.")
        self.env[name] = {"type": "dict", "value": value, "constant": False}

    def box_put(self, items): # box_put mydict, key_expr, val_expr
        name_token = items[0]
        key_node = items[1]
        value_node = items[2]
        name = str(name_token.value)

        if name not in self.env or self.env[name]["type"] != "dict":
            raise NameError(f"'{name}' não é um dicionário declarado para box_put.")
        
        key = self._resolve(key_node) # Chave pode ser int ou str
        val = self._resolve(value_node)
        # Dicionários Python podem ter chaves de vários tipos, mas Snask pode restringir a str.
        self.env[name]["value"][str(key)] = val # Forçando chave a str por simplicidade

    # box_get é melhor tratado por index_access: mydict[key]


    # ==== ESPERA ====
    def wait_stmt(self, items): # items: [duration_expr_node]
        duration = self._resolve(items[0])
        if not isinstance(duration, (int, float)):
            raise TypeError("A duração para 'wait' deve ser um número.")
        if duration < 0:
            raise ValueError("A duração para 'wait' não pode ser negativa.")
        time.sleep(duration)

    # ==== CONVERSÃO ====
    def convert(self, items): # convert VAR_NAME to TYPE_STR -> items: [Token(NAME, var), type_node]
        name_token = items[0]
        type_node = items[1] # Nó 'type'
        
        name = str(name_token.value)
        target_type_str = self.type(type_node.children if hasattr(type_node, 'data') else type_node)

        if name not in self.env:
            raise NameError(f"Variável '{name}' não encontrada para conversão.")

        original_value = self.env[name]["value"]
        converted_value = None
        try:
            if target_type_str == "int": converted_value = int(original_value)
            elif target_type_str == "str": converted_value = str(original_value)
            elif target_type_str == "float": converted_value = float(original_value)
            elif target_type_str == "bool": converted_value = bool(original_value) # Pythonic bool conversion
            else:
                raise TypeError(f"Conversão para tipo '{target_type_str}' não suportada.")
        except ValueError as e: # Erro na conversão int(), float()
            raise ValueError(f"Não foi possível converter '{original_value!r}' (tipo {self.typeis([original_value])}) para '{target_type_str}': {e}")

        self.env[name]["type"] = target_type_str
        self.env[name]["value"] = converted_value
        debug_print(f"convert: Variável '{name}' convertida para tipo '{target_type_str}', novo valor: {converted_value!r}")


    # ==== BIBLIOTECAS E ARQUIVOS ====
    def use_lib(self, items): # items: [libname_expr_node]
        libname_raw = self._resolve(items[0])
        if not isinstance(libname_raw, str):
            raise TypeError("O nome da biblioteca para 'use' deve ser uma string.")

        # Tenta importar como Python
        try:
            if not libname_raw.isidentifier(): # Checagem básica
                 print(f"AVISO: Nome de biblioteca Python '{libname_raw}' pode não ser um identificador válido.")
            
            lib_module = importlib.import_module(libname_raw)
            self.env[libname_raw] = {"type": "module", "value": lib_module, "constant": True} # Módulos são constantes
            print(f"Biblioteca Python '{libname_raw}' carregada.")
            return
        except ModuleNotFoundError:
            debug_print(f"use_lib: Biblioteca Python '{libname_raw}' não encontrada, tentando Snask.")
        except Exception as e_py:
            print(f"ERRO ao carregar biblioteca Python '{libname_raw}': {e_py}")
            # Decidir se continua para Snask ou para aqui

        # Tenta carregar como arquivo Snask
        snask_lib_path_options = [
            os.path.join("libs", libname_raw + ".snask"),
            libname_raw + ".snask"
        ]
        actual_path_to_load = None
        for p in snask_lib_path_options:
            if os.path.exists(p):
                actual_path_to_load = p
                break
        
        if not actual_path_to_load:
            print(f"Biblioteca '{libname_raw}' não encontrada (nem Python, nem Snask em ./libs/ ou ./).")
            return

        if self.parser is None:
            print("ERRO: Parser não está disponível em SnaskInterpreter para carregar biblioteca Snask.")
            return

        try:
            with open(actual_path_to_load, "r", encoding="utf-8") as f:
                snask_code = f.read()
            
            print(f"Carregando biblioteca Snask '{libname_raw}' de '{actual_path_to_load}'...")
            # Executar o código da biblioteca Snask.
            # Opções:
            # 1. Novo interpretador para isolamento (mais complexo para expor símbolos).
            # 2. Mesmo interpretador (atual): funções e vars da lib entram no escopo atual.
            #    Isso pode ser o desejado para 'use'.
            lib_tree = self.parser.parse(snask_code)
            # Salvar e restaurar estado de 'returning' para que um 'return' na lib não afete o chamador
            prev_returning, prev_ret_val = self.returning, self.return_value
            prev_break, prev_skip = self._is_break_signal, self._is_skip_signal
            self.returning, self.return_value = False, None
            self._is_break_signal, self._is_skip_signal = False, False

            self._execute_tree(lib_tree) # Executa as declarações da lib

            self.returning, self.return_value = prev_returning, prev_ret_val
            self._is_break_signal, self._is_skip_signal = prev_break, prev_skip
            print(f"Biblioteca Snask '{libname_raw}' carregada e executada.")

        except FileNotFoundError: # Já checado, mas por garantia
             print(f"ERRO: Arquivo da biblioteca Snask '{actual_path_to_load}' desapareceu.")
        except Exception as e_snask:
            print(f"ERRO ao carregar ou executar biblioteca Snask '{libname_raw}' de '{actual_path_to_load}': {e_snask}")


    def file_read_stmt(self, items): # readfile FILEPATH_EXPR into VAR_NAME_TOKEN
        filepath_node = items[0]
        var_name_token = items[1]

        filepath = str(self._resolve(filepath_node))
        var_name = str(var_name_token.value)

        try:
            with open(filepath, "r", encoding="utf-8") as file:
                content = file.read()
            self.env[var_name] = {"type": "str", "value": content, "constant": False}
        except FileNotFoundError:
            raise FileNotFoundError(f"Arquivo '{filepath}' não encontrado para leitura.")
        except Exception as e:
            raise IOError(f"Erro ao ler arquivo '{filepath}': {e}")


    def file_write_stmt(self, items): # writefile FILEPATH_EXPR with CONTENT_EXPR
        filepath_node = items[0]
        content_node = items[1]

        filepath = str(self._resolve(filepath_node))
        content_to_write = str(self._resolve(content_node)) # Força para string

        try:
            with open(filepath, "w", encoding="utf-8") as file:
                file.write(content_to_write)
            # print(f"Conteúdo escrito em '{filepath}'.") # Opcional
        except Exception as e:
            raise IOError(f"Erro ao escrever no arquivo '{filepath}': {e}")

    # _check_reactive_rules (mantenha sua implementação se estiver usando)
    def _check_reactive_rules(self):
        # Seu código original para reactive_rules
        for i, (condition_node, body_nodes) in enumerate(self.reactive_rules):
            try:
                resolved = self._resolve(condition_node)
                condition_key = f"reactive_rule_{i}" # Chave única para esta regra

                if resolved: # Se a condição for verdadeira
                    if condition_key not in self.triggered_conditions:
                        for stmt_node in body_nodes:
                            self._execute(stmt_node)
                            if self.returning or self._is_break_signal or self._is_skip_signal: return
                        self.triggered_conditions.add(condition_key) # Marcar como disparada
                else: # Se a condição se tornou falsa
                    if condition_key in self.triggered_conditions:
                        self.triggered_conditions.remove(condition_key) # Resetar
            except Exception as e:
                print(f"Erro na regra reativa {i} (condição: {condition_node}): {e}")


# --- Fim da classe SnaskInterpreter ---

# Exemplo de uso (requer a gramática e o parser definidos em outro lugar)
#
# if __name__ == '__main__':
#     # Defina sua gramática Lark aqui ou carregue de um arquivo
#     grammar = r"""
#         start: statement*
#         // ... (resto da sua gramática adaptada para os nomes de métodos do Transformer)
#         // Exemplo: var_decl_stmt: "make" NAME ":" type "=" expr -> var_decl
#         //          when_stmt: "when" expr "{" statement* "}" -> when
#         //          comparison: expr "over" expr -> over
#         //                    | expr "under" expr -> lt  // <-- Mapeamento crucial
#         // ... etc.
#
#         type: "int" | "str" | "float" | "bool" | "list" | "dict" | "void" | "any" | "module"
#
#         COMMENT: /\/\/.*/ "%ignore"
#         %import common.CNAME -> NAME
#         %import common.SIGNED_NUMBER -> NUMBER
#         %import common.ESCAPED_STRING
#         %import common.WS
#         %ignore WS
#         %ignore COMMENT
#     """
#     try:
#         snask_parser = Lark(grammar, parser='lalr', start='start')
#     except Exception as e_lark:
#         print(f"Erro ao criar parser Lark: {e_lark}")
#         exit()
#
#     snask_code_exemplo = """
#         make idade: int = 20;
#
#         when idade over 18 {
#          shoo("Maior de idade!");
#         }
#
#         when idade under 18 {
#          shoo("Menor de idade!");
#         }
#
#         make nome: str = "Snask";
#         when nome is "Snask" {
#             shoo("Olá, Snask!");
#         }
#     """
#
#     print("\n--- Testando Snask Interpreter ---")
#     DEBUG_MODE = True # Habilitar prints de depuração para o teste
#     interpreter = SnaskInterpreter(parser=snask_parser)
#     try:
#         tree = snask_parser.parse(snask_code_exemplo)
#         if DEBUG_MODE:
#             print("\n--- Árvore Sintática ---")
#             print(tree.pretty())
#         print("\n--- Execução ---")
#         interpreter._execute_tree(tree)
#     except Exception as e_interp:
#         print(f"\nERRO DE INTERPRETAÇÃO: {e_interp}")
#         import traceback
#         traceback.print_exc()
#
#     print("\n--- Ambiente Final ---")
#     for k, v_entry in interpreter.env.items():
#         print(f"{k}: {v_entry['value']} (type: {v_entry['type']}{', const' if v_entry.get('constant') else ''})")
#     for k, f_entry in interpreter.functions.items():
#         print(f"func {k} ({f_entry['params']}) -> {f_entry['return_type']}")