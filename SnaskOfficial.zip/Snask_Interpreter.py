from lark import Transformer, Lark, Token
import time
import os
import requests
import json
from lark.tree import Tree
import importlib

class SnaskInterpreter(Transformer):
    def __init__(self, parser=None):
        self.env = {}
        self.functions = {}
        self.returning = False
        self.return_value = None
        self.parser = parser

    # ==== VARIÁVEIS E CONSTANTES ====
    def var_decl(self, items):
        name = str(items[0])
        var_type = str(items[1])
        value = self._resolve(items[2])
        if name.isdigit():
         raise ValueError(f"Nome inválido para variável: '{name}' não pode ser um número.")
        if not self._check_type(value, var_type):
            raise TypeError(f"Tipo inválido para '{name}'. Esperado {var_type}, recebeu {type(value).__name__}.")

        self.env[name] = {"type": var_type, "value": value}

    def type(self, items):
        if not items:
            raise ValueError("Tipo vazio detectado")
        return str(items[0])

    def var_set(self, items):
        name = str(items[0])
        value = self._resolve(items[1])

        if name not in self.env:
            raise NameError(f"Variável '{name}' não foi declarada.")

        expected_type = self.env[name]["type"]
        if not self._check_type(value, expected_type):
            raise TypeError(f"Tipo inválido ao alterar '{name}'. Esperado {expected_type}.")

        self.env[name]["value"] = value
    

        def lenof(self, items):
         val = self._resolve(items[0])
         return len(val)

    def typeis(self, items):
     val = self._resolve(items[0])
     py_type = type(val).__name__
     snask_types = {
        "str": "str",
        "int": "int",
        "float": "float",
        "list": "list",
        "dict": "dict",
        "bool": "bool",
        "void": "void",
    }
     return snask_types.get(py_type, "unknown")



    def toupper(self, items):
        val = self._resolve(items[0])
        if not isinstance(val, str):
            raise TypeError("toupper espera uma string.")
        return val.upper()

    def tolower(self, items):
        val = self._resolve(items[0])
        if not isinstance(val, str):
            raise TypeError("tolower espera uma string.")
        return val.lower()

    def startswith(self, items):
        val = self._resolve(items[0])
        prefix = self._resolve(items[1])
        if not isinstance(val, str) or not isinstance(prefix, str):
            raise TypeError("startswith espera dois argumentos do tipo string.")
        return val.startswith(prefix)

    def endswith(self, items):
        val = self._resolve(items[0])
        suffix = self._resolve(items[1])
        if not isinstance(val, str) or not isinstance(suffix, str):
            raise TypeError("endswith espera dois argumentos do tipo string.")
        return val.endswith(suffix)

    def list_literal(self, items):
     return [self._resolve(item) for item in items]

    def dict_literal(self, items):
     d = {}
     for i in range(0, len(items), 2):
        key = str(items[i])
        value = self._resolve(items[i+1])
        d[key] = value
     return d

    def index_access(self, items):
     collection = self._resolve(items[0])
     index = self._resolve(items[1])
     return collection[index]


    def jsonparse(self, items):
     raw = self._resolve(items[0])
     return json.loads(raw)



    def httpget(self, items):
     url = self._resolve(items[0])
     try:
        response = requests.get(url)
        return response.text
     except Exception as e:
        return f"Erro na requisição: {e}"   
    def _check_type(self, value, expected):
     
     if expected == "int":
        return isinstance(value, int)
     elif expected == "str":
        return isinstance(value, str)
     elif expected == "list":
        return isinstance(value, list)
     elif expected == "dict":
        return isinstance(value, dict)
     elif expected == "bool":
        return isinstance(value, bool)
     elif expected == "float":
        return isinstance(value, float)
     elif expected == "void":
        return value is None
     else:
        raise TypeError(f"Tipo '{expected}' não é reconhecido pela linguagem.")


    def var_zap(self, items):
        name = str(items[0])
        if name in self.env:
            del self.env[name]

    def const_decl(self, items):
        self.var_decl(items)

    

    

    
    # ==== INPUT E OUTPUT ====
    def print_stmt(self, items):
     base = self._resolve(items[0])  # Primeiro item é a string base

    # Verifica se há substituições com .cdr
     if len(items) > 1 and isinstance(items[1], list):
        replacements = [self._resolve(item) for item in items[1]]
     else:
        replacements = []

    # Substituição segura dos placeholders
     if isinstance(base, str) and '{}' in base:
        for repl in replacements:
            base = base.replace("{}", str(repl), 1)

     print(base)


    def cdr_chain(self, items):
        return items

    def input_stmt(self, items):
        name = str(items[0])
        var_type = str(items[1])
        user_input = input("> ")

        if var_type == "int":
            value = int(user_input)
        elif var_type == "str":
            value = str(user_input)
        else:
            raise TypeError(f"Tipo '{var_type}' não suportado para input.")

        self.env[name] = {"type": var_type, "value": value}

    def inputnum_stmt(self, items):
        self.input_stmt(items)

    def inputtxt_stmt(self, items):
        self.input_stmt(items)

    # ==== EXPRESSÕES ====
    def add(self, items):
        left = self._resolve(items[0])
        right = self._resolve(items[1])
        if isinstance(left, str) or isinstance(right, str):
            return str(left) + str(right)
        return left + right

    def sub(self, items):
        return self._resolve(items[0]) - self._resolve(items[1])

    def mul(self, items):
        return self._resolve(items[0]) * self._resolve(items[1])

    def div(self, items):
        return self._resolve(items[0]) / self._resolve(items[1])

    def is_(self, items):
        return self._resolve(items[0]) == self._resolve(items[1])

    def aint(self, items):
        return self._resolve(items[0]) != self._resolve(items[1])

    def number(self, token):
        return int(token[0])

    
    def ESCAPED_STRING(self, token):
     return str(token[1:-1])  # Remove aspas do início e fim




    def var(self, token):
        return str(token[0])

    def paren_expr(self, items):
        return self._resolve(items[0])
    def var(self, token):
     return {"var": str(token[0])}

    

    def _resolve(self, val):
     if isinstance(val, Tree):
        method = getattr(self, val.data, None)
        if method:
            return method(val.children)
        else:
            raise ValueError(f"Expressão desconhecida: {val.data}")

     if isinstance(val, dict) and "var" in val:
        varname = val["var"]
        if varname not in self.env:
            raise NameError(f"Variável '{varname}' não foi encontrada.")
        return self.env[varname]["value"]

     elif isinstance(val, Token):
        if val.type == "NUMBER":
            return int(val.value)
        elif val.type == "STRING":
            return str(val.value[1:-1])  # Remove aspas
        elif val.type == "NAME":
            varname = val.value
            if varname not in self.env:
                raise NameError(f"Variável '{varname}' não foi encontrada.")
            return self.env[varname]["value"]

     return val



    # ==== FUNÇÕES ====
    
    def func_decl(self, items):
        name = str(items[0])
        params = items[1:-2]
        return_type = str(items[-2])
        body = items[-1:]

        params_dict = {}
        for param in params:
            if param is None:
                continue
            param_name = str(param[0])
            param_type = str(param[1])
            params_dict[param_name] = param_type

        self.functions[name] = {"params": params_dict, "return_type": return_type, "body": body}

    def func_call(self, items):
        func_name = str(items[0])
        args = items[1] if len(items) > 1 else []

        if args is None:
            args = []

        if not isinstance(args, list):
            args = [args]

        expected_args = self.functions[func_name]["params"]

        if len(args) != len(expected_args):
            raise Exception(f"Função '{func_name}' esperava {len(expected_args)} argumentos, recebeu {len(args)}.")

        return self.call_function(func_name, args)

    def call_function(self, func_name, args):
        func = self.functions[func_name]
        old_env = self.env.copy()

        self.env = {}

        for (param_name, param_type), arg_value in zip(func["params"].items(), args):
            if not self._check_type(arg_value, param_type):
                raise TypeError(f"Tipo inválido para argumento '{param_name}' da função '{func_name}'.")
            self.env[param_name] = {"type": param_type, "value": arg_value}

        self.returning = False
        self.return_value = None

        for stmt in func["body"]:
            self._execute(stmt)
            if self.returning:
                break

        result = self.return_value
        self.returning = False
        self.return_value = None

        self.env = old_env

        if func["return_type"] != "void" and result is None:
            raise Exception(f"Função '{func_name}' deveria retornar um valor.")

        return result

    def return_stmt(self, items):
        self.return_value = self._resolve(items[0])
        self.returning = True

    # ==== CONTROLE DE FLUXO ====
    def when_stmt(self, items):
        if self._resolve(items[0]):
            for stmt in items[1:]:
                self._execute(stmt)

    def loop_spin(self, items):
        while self._resolve(items[0]):
            for stmt in items[1:]:
                self._execute(stmt)
                if self.returning:
                    break

    def loop_loopy(self, items):
        while True:
            for stmt in items:
                self._execute(stmt)
                if self.returning:
                    return

    def loop_breaky(self, _):
        self.returning = True

    def loop_skipit(self, _):
        pass

    # ==== LISTAS ====
    def pack_decl(self, items):
        name = str(items[0])
        values = [self._resolve(val) for val in items[2:]]
        self.env[name] = {"type": "list", "value": values}

    def pack_add(self, items):
        name = str(items[0])
        value = self._resolve(items[1])
        self.env[name]["value"].append(value)

    def pack_get(self, items):
        name = str(items[0])
        index = self._resolve(items[1])
        return self.env[name]["value"][index]

    # ==== DICIONÁRIOS ====
    def box_decl(self, items):
        name = str(items[0])
        box = {}
        for pair in items[2:]:
            key = str(pair[0])
            val = self._resolve(pair[1])
            box[key] = val
        self.env[name] = {"type": "dict", "value": box}

    def box_put(self, items):
        box = str(items[0])
        key = str(items[1])
        value = self._resolve(items[2])
        self.env[box]["value"][key] = value

    def box_get(self, items):
        box = str(items[0])
        key = str(items[1])
        return self.env[box]["value"][key]

    # ==== ESPERA ====
    def wait_stmt(self, items):
        time.sleep(self._resolve(items[0]))

    # ==== CONVERSÃO ====
        def convert(self, items):
         name = str(items[0])
         target_type = str(items[1])

         if name not in self.env:
            raise NameError(f"Variável '{name}' não encontrada.")

         value = self.env[name]["value"]

         if target_type == "int":
            value = int(value)
         elif target_type == "str":
            value = str(value)
         elif target_type == "float":
            value = float(value)
         elif target_type == "bool":
            value = bool(value)
         else:
            raise TypeError(f"Conversão para '{target_type}' não suportada.")

         self.env[name] = {"type": target_type, "value": value}


    # ==== BIBLIOTECAS E ARQUIVOS ====
    def use_lib(self, items):
        # Carrega bibliotecas Python e Snask.
        libname = str(items[0])

        # Primeiro tenta importar como biblioteca Python
        try:
            lib = importlib.import_module(libname)
            self.env[libname] = {"type": "module", "value": lib}
            print(f"Biblioteca Python '{libname}' carregada com sucesso.")
        except ModuleNotFoundError:
            print(f"Biblioteca Python '{libname}' não encontrada. Tentando carregar como Snask.")

            # Se não encontrar, tenta carregar como arquivo Snask
            lib_path = os.path.join("libs", libname + ".snask")
            if os.path.exists(lib_path):
                with open(lib_path, "r", encoding="utf-8") as f:
                    code = f.read()
                    tree = self.parser.parse(code)
                    self.transform(tree)
                    print(f"Biblioteca Snask '{libname}' carregada com sucesso.")
            else:
                print(f"Biblioteca '{libname}' não encontrada.")

    def file_read_stmt(self, items):
        filename = str(items[0])
        var_name = str(items[1])
        try:
            with open(filename, "r", encoding="utf-8") as file:
                content = file.read()
            self.env[var_name] = {"type": "str", "value": content}
        except FileNotFoundError:
            print(f"Arquivo '{filename}' não encontrado.")

    def file_write_stmt(self, items):
        filename = str(items[0])
        content = self._resolve(items[1])
        try:
            with open(filename, "w", encoding="utf-8") as file:
                file.write(content)
        except Exception as e:
            print(f"Erro ao escrever no arquivo: {e}")

def visit_print_stmt(self, tree):
    value = self.visit(tree.children[0])  # Pega o que está dentro dos parênteses
    print(value)
    
    if len(tree.children) > 1:
        # Se tiver .cdr, concatena os outros valores
        extra_values = [self.visit(expr) for expr in tree.children[1].children]
        for val in extra_values:
            print(val)

def _execute(self, stmt):
    # Verifica se o 'stmt' tem atributo 'data' (indica que é um nó de árvore)
    if hasattr(stmt, "data"):
        method = getattr(self, stmt.data, None)  # Busca o método para esse tipo de 'stmt'
        if method:
            method(stmt.children)  # Executa o método correspondente com os filhos do nó

# Método para lidar com o 'loopy'
def loopy(self, children):
    """
    Executa um loop infinito com os comandos dentro do bloco 'loopy'.
    """
    while True:  # Inicia um loop infinito
        for child in children:  # Itera sobre as instruções dentro do 'loopy'
            self._execute(child)  # Executa a instrução

            # Opcional: Se houver uma pausa, como 'snooze', execute também
            if hasattr(child, "data") and child.data == "snooze":
                time.sleep(int(child.children[0]))  # 'children[0]' é o valor do snooze (em segundos)

